#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "=== Rendering how-magnets-work at 1920x1080 @ 60fps (Hardware GPU) ==="
node render-final.mjs "how-magnets-work-1080p60"
echo ""
echo "=== Render complete: renders/how-magnets-work-1080p60.mp4 ==="
