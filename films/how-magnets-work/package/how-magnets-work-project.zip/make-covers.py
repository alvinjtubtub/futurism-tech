#!/usr/bin/env python3
"""
Generate premium THUMBNAIL.png (1280x720) and TIKTOK-COVER.png (1080x1920)
for How Magnets Work.
"""
import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

def make_covers():
    film_dir = os.path.dirname(os.path.abspath(__file__))
    mascot_path = os.path.join(film_dir, "assets", "mascot", "poses", "present.png")
    mascot_img = Image.open(mascot_path).convert("RGBA")
    
    font_bold_xl = ImageFont.truetype("/System/Library/Fonts/Avenir Next.ttc", 84, index=8)
    font_bold_lg = ImageFont.truetype("/System/Library/Fonts/Avenir Next.ttc", 72, index=8)
    font_bold_md = ImageFont.truetype("/System/Library/Fonts/Avenir Next.ttc", 50, index=8)
    font_bold_sm = ImageFont.truetype("/System/Library/Fonts/Avenir Next.ttc", 34, index=8)
    font_tag = ImageFont.truetype("/System/Library/Fonts/Avenir Next.ttc", 22, index=0)
    font_chip = ImageFont.truetype("/System/Library/Fonts/Avenir Next.ttc", 26, index=0)

    # ==========================================
    # 1. 16:9 Thumbnail (1280x720)
    # ==========================================
    W1, H1 = 1280, 720
    t1 = Image.new("RGBA", (W1, H1), "#F6F2EA")
    d1 = ImageDraw.Draw(t1)

    # Floor grid on bottom 40%
    for gy in range(480, H1, 40):
        d1.line([(0, gy), (W1, gy)], fill=(148, 194, 173, 50), width=2)
    for gx in range(40, W1, 60):
        top_x = int(W1 / 2 + (gx - W1 / 2) * 0.45)
        d1.line([(top_x, 480), (gx, H1)], fill=(148, 194, 173, 40), width=2)

    # Kape Mascot on left
    m1_h = 520
    m1_w = int(mascot_img.width * (m1_h / mascot_img.height))
    m1 = mascot_img.resize((m1_w, m1_h), Image.Resampling.LANCZOS)
    t1.paste(m1, (40, 200), m1)

    # Main Headline Card on right
    cw1, ch1 = 780, 250
    cx1, cy1 = 450, 80

    # Soft drop shadow
    s1 = Image.new("RGBA", (W1, H1), (0, 0, 0, 0))
    s1_d = ImageDraw.Draw(s1)
    s1_d.rounded_rectangle([cx1 + 4, cy1 + 14, cx1 + cw1 - 4, cy1 + ch1 + 14], radius=32, fill=(11, 30, 63, 30))
    s1 = s1.filter(ImageFilter.GaussianBlur(16))
    t1 = Image.alpha_composite(t1, s1)
    d1 = ImageDraw.Draw(t1)

    # Card body
    d1.rounded_rectangle([cx1, cy1, cx1 + cw1, cy1 + ch1], radius=28, fill="#FFFFFF", outline="#ECE5D8", width=3)

    # Kicker
    k1 = "PHYSICS & MAGNETIC FIELDS"
    d1.text((cx1 + 36, cy1 + 26), k1, font=font_tag, fill="#B8500A")

    # Titles
    l1 = "HOW MAGNETS WORK"
    d1.text((cx1 + 36, cy1 + 64), l1, font=font_bold_lg, fill="#0B1E3F")
    l2 = "THE INVISIBLE FORCE FIELD"
    d1.text((cx1 + 36, cy1 + 148), l2, font=font_bold_sm, fill="#0A7468")

    # Badges row under title card
    # Bar Magnet Graphic Card
    b1_w, b1_h = 420, 180
    b1_x, b1_y = 450, 370
    d1.rounded_rectangle([b1_x, b1_y, b1_x + b1_w, b1_y + b1_h], radius=24, fill="#0B1E3F", outline="#0F9F8F", width=2)
    
    # Draw mini bar magnet
    d1.rounded_rectangle([b1_x + 30, b1_y + 36, b1_x + 190, b1_y + 106], radius=14, fill="#B02A30")
    d1.text((b1_x + 85, b1_y + 48), "N", font=font_bold_md, fill="#FFFFFF")
    d1.rounded_rectangle([b1_x + 190, b1_y + 36, b1_x + 350, b1_y + 106], radius=14, fill="#2563EB")
    d1.text((b1_x + 245, b1_y + 48), "S", font=font_bold_md, fill="#FFFFFF")
    d1.text((b1_x + 30, b1_y + 128), "Opposites Attract • Like Repel", font=font_chip, fill="#ECE5D8")

    # Microscopic Domains Badge
    b2_w, b2_h = 330, 180
    b2_x, b2_y = 900, 370
    d1.rounded_rectangle([b2_x, b2_y, b2_x + b2_w, b2_y + b2_h], radius=24, fill="#FFFFFF", outline="#FF7A1A", width=2)
    d1.text((b2_x + 24, b2_y + 24), "ATOMIC DOMAINS", font=font_tag, fill="#B8500A")
    d1.text((b2_x + 24, b2_y + 58), "Aligned", font=font_bold_md, fill="#0B1E3F")
    d1.text((b2_x + 24, b2_y + 128), "Billions of Dipoles", font=font_chip, fill="#5B6478")

    thumb_path = os.path.join(film_dir, "THUMBNAIL.png")
    t1.convert("RGB").save(thumb_path, "PNG", optimize=True)
    print(f"Created {thumb_path} (1280x720)")

    # ==========================================
    # 2. 9:16 TikTok Cover (1080x1920)
    # ==========================================
    W2, H2 = 1080, 1920
    t2 = Image.new("RGBA", (W2, H2), "#F6F2EA")
    d2 = ImageDraw.Draw(t2)

    # Floor grid on bottom 40% (y: 1200 to 1920)
    for gy in range(1200, H2, 60):
        d2.line([(0, gy), (W2, gy)], fill=(148, 194, 173, 50), width=2)
    for gx in range(60, W2, 100):
        top_x = int(W2 / 2 + (gx - W2 / 2) * 0.35)
        d2.line([(top_x, 1200), (gx, H2)], fill=(148, 194, 173, 40), width=2)

    # Top Brand Tag
    hw, hh = 440, 56
    hx = (W2 - hw) // 2
    hy = 110
    d2.rounded_rectangle([hx, hy, hx + hw, hy + hh], radius=28, fill=(255, 255, 255, 230), outline="#ECE5D8", width=2)
    bt = "TECH EXPLANASYON • HOW IT WORKS"
    d2.text((hx + 30, hy + 14), bt, font=font_tag, fill="#0B1E3F")

    # Hero 2-Liner Headline Card (y: 200 - 540)
    cw2, ch2 = 980, 330
    cx2 = (W2 - cw2) // 2
    cy2 = 200

    s2 = Image.new("RGBA", (W2, H2), (0, 0, 0, 0))
    s2_d = ImageDraw.Draw(s2)
    s2_d.rounded_rectangle([cx2 + 6, cy2 + 18, cx2 + cw2 - 6, cy2 + ch2 + 18], radius=44, fill=(11, 30, 63, 35))
    s2 = s2.filter(ImageFilter.GaussianBlur(22))
    t2 = Image.alpha_composite(t2, s2)
    d2 = ImageDraw.Draw(t2)

    # Card body
    d2.rounded_rectangle([cx2, cy2, cx2 + cw2, cy2 + ch2], radius=40, fill="#FFFFFF", outline="#ECE5D8", width=3)

    # Kicker inside card
    k2 = "PHYSICS & MAGNETIC FIELDS"
    d2.text((cx2 + 44, cy2 + 34), k2, font=font_tag, fill="#B8500A")

    # 2-Liner
    d2.text((cx2 + 44, cy2 + 82), "PAANO GUMAGANA", font=font_bold_xl, fill="#0B1E3F")
    d2.text((cx2 + 44, cy2 + 186), "ANG MGA MAGNET?", font=font_bold_xl, fill="#2563EB")

    # Center Feature Badges (y: 570 - 1050)
    # Bar Magnet Display Card
    m_box_w, m_box_h = 980, 210
    m_box_x = (W2 - m_box_w) // 2
    m_box_y = 570
    d2.rounded_rectangle([m_box_x, m_box_y, m_box_x + m_box_w, m_box_y + m_box_h], radius=36, fill="#0B1E3F", outline="#0F9F8F", width=3)
    
    # North / South split
    d2.rounded_rectangle([m_box_x + 40, m_box_y + 40, m_box_x + 460, m_box_y + 130], radius=20, fill="#B02A30")
    d2.text((m_box_x + 190, m_box_y + 55), "NORTH", font=font_bold_md, fill="#FFFFFF")
    d2.rounded_rectangle([m_box_x + 480, m_box_y + 40, m_box_x + 900, m_box_y + 130], radius=20, fill="#2563EB")
    d2.text((m_box_x + 630, m_box_y + 55), "SOUTH", font=font_bold_md, fill="#FFFFFF")
    d2.text((m_box_x + 330, m_box_y + 152), "Toroidal 3D Magnetic Flux Lines", font=font_chip, fill="#ECE5D8")

    # Domains & Earth stats
    sw, sh = 470, 200
    # Left: Domains
    s_lx, s_ly = cx2, 810
    d2.rounded_rectangle([s_lx, s_ly, s_lx + sw, s_ly + sh], radius=32, fill="#FFFFFF", outline="#0F9F8F", width=2)
    d2.text((s_lx + 32, s_ly + 26), "MICROSCOPIC SCALE", font=font_tag, fill="#5B6478")
    d2.text((s_lx + 32, s_ly + 64), "Domains", font=font_bold_md, fill="#0A7468")
    d2.text((s_lx + 32, s_ly + 138), "Billions of Tiny Dipoles", font=font_chip, fill="#0B1E3F")

    # Right: Earth Core
    s_rx, s_ry = cx2 + sw + 40, 810
    d2.rounded_rectangle([s_rx, s_ry, s_rx + sw, s_ry + sh], radius=32, fill="#FFFFFF", outline="#FF7A1A", width=2)
    d2.text((s_rx + 32, s_ly + 26), "PLANETARY CORE", font=font_tag, fill="#B8500A")
    d2.text((s_rx + 32, s_ly + 64), "Earth Field", font=font_bold_md, fill="#0B1E3F")
    d2.text((s_rx + 32, s_ly + 138), "Guides Compass Needles", font=font_chip, fill="#5B6478")

    # Mascot on bottom floor (y: 1040 - 1880)
    m2_h = 860
    m2_w = int(mascot_img.width * (m2_h / mascot_img.height))
    m2 = mascot_img.resize((m2_w, m2_h), Image.Resampling.LANCZOS)
    t2.paste(m2, ((W2 - m2_w) // 2, 1060), m2)

    tiktok_path = os.path.join(film_dir, "TIKTOK-COVER.png")
    t2.convert("RGB").save(tiktok_path, "PNG", optimize=True)
    print(f"Created {tiktok_path} (1080x1920)")

if __name__ == "__main__":
    make_covers()
