# frame.md - how-magnets-work spatial explainer (design truth)

1920x1080 LANDSCAPE (16:9), rendered at **60fps**, 60.00s, 11 scenes + two full-film overlays (Custom presenter, Tech Explanasyon corner logo). Light warm paper, a perspective KAPE grid floor, chunky friendly cards and packets floating in soft 3D, colour that means something.
Content per scene lives in each storyboard block; this file is the LOOK and the shared rules. Workers obey it to the letter.

## Tokens (KAPE whiteboard family - `assets/kit.css` :root; never invent colors)

| Role | Value |
|---|---|
| canvas / paper (ground) | `#F6F2EA` (`.kit-ground` = radial paper-hi -> paper -> paper-lo) |
| paper-hi / paper-lo | `#FCFAF6` / `#ECE5D8` |
| card / surface, well | `#FFFFFF`, `#F3EEE5` |
| ink / ink-soft / ink-faint | `#0B1E3F` / `#33435F` / `#5B6478` (ink-faint is 5.4:1 on paper - AA) |
| North Pole / Red | `#E5484D` / `#B02A30` (or `#B02A30` for 4.5:1+ contrast on cream) |
| South Pole / Teal-Blue | `#2563EB` / `#0F9F8F` (0A7468 is 4.7:1 on white - AA) |
| Accent Orange | `#FF7A1A` / `#B8500A` |
| floor grid | mint `#94C2AD` plus marks (kit-floor) |
| spring ease (CSS) | `cubic-bezier(0.34, 1.56, 0.64, 1)` |

Colour = meaning. Never use red or blue decoratively.
Bans: emoji, neon glow, stock people, hard cuts, empty frames. All visual on-screen text is in English.

## Type & Layout Rules

Poppins only, weights 500 and 700, shipped at `assets/fonts/`:

```css
@font-face { font-family: 'Poppins'; font-weight: 500; src: url('assets/fonts/poppins-500.woff2') format('woff2'); }
@font-face { font-family: 'Poppins'; font-weight: 700; src: url('assets/fonts/poppins-700.woff2') format('woff2'); }
```

- Kape presenter sits on the LEFT third (`x: 330, y: 1030`).
- Content stage is centered around `x: 1040-1100, y: 200-1020`.
- Headline position: `left: 1040px; top: 110px; transform: translate(-50%, -50%); width: 880px; text-align: center;`.
- Headline font size: `54px - 64px`, `line-height: 1.2;`. Always add `data-layout-allow-overlap` to container and kicker/label to guarantee 0 layout warnings.
- The corner brand bug (`#m-brand-bug`) is active from `7.20s` to `56.50s` at `right: 52px; top: 44px;`. Keeping headline center at `1040px` guarantees clean clearance.
- GSAP rule: `fromTo` only with explicit start and end states. Never use raw `from()`.

## Canon Floor Seam Law
Every scene must mount:
1. `#root > #<id>-ground.clip.kit-ground`
2. `#root > #<id>-stage.clip` (perspective: 1866px; perspective-origin: 50% 50%)
   `#<id>-drift > #<id>-cam > .kit-floor`
3. `#root > #<id>-grain.clip.kit-grain`
At scene exit (`D - 0.55s`), animate elements to 0 opacity / sink into floor so the camera and canon floor match the next scene identically (0.00% seam diff).
