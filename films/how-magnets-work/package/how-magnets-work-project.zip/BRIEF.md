---
workflow: general-video
flow: explainer
storyboard: yes
message: "How Magnets Work"
destination: social (YouTube / Reels / TikTok)
aspect: 1920x1080
fps: 60
language: Taglish / English visuals
length: 60s
audience: Curious viewers, students, tech enthusiasts
angle: spatial 3D concept explainer with mascot presenter
---

## Intent

A 60-second 16:9 widescreen spatial motion design explainer breaking down the science of magnets: from the fridge magnet hook to microscopic magnetic domains, electron alignment, 3D curved field lines, North and South poles attraction and repulsion, cutting magnets, Earth's geomagnetic core, and electromagnets.

## Assets

- `assets/audio/vo-master.wav` - Mastered narration (-16.5 LUFS, -1.5 dBTP, 60.00s total with tail hold).
- `src/timing/vo-words.json` - faster-whisper word-level timestamp cue sheet.
- `assets/mascot/` - KAPE demo mascot poses (wave, present, point, think, thumbs-up, celebrate, idle) with dynamic blinking and voice bob.
- `assets/brand/` - Tech Explanasyon branding.
- `assets/fonts/` - Poppins 500 & 700.

## Design Laws & Customizations

- Standard 16:9 widescreen (1920x1080 @ 60fps), warm paper `#F6F2EA` palette.
- All on-screen visual text in **English**.
- Presenter Kape on left third (`x: 330, y: 1030`), content stage centered at `x: 1040-1100, y: 200-1020`.
- Zero exclamation marks (`!`) in all scripts and visual typography.
- Scene 1 displays hook question immediately for muted scrollers: *"Why Do Magnets Stick to Your Fridge?"*.
- Scene 11 closing: Exact sign-off: *"Follow me for more tech explained. See yah."*
- Zero blank visuals: Every scene features a concrete spatial 3D diagram or physical hardware model.
- Exactly 11 scenes cut cleanly during natural speech pauses.
- 5 Quality Gates must pass before shipping.
