# Storyboard - How Magnets Work

11 scenes, 60.00s total. One idea per frame. Real blueprint per scene.
Presenter stands in the LEFT third (x 40-620); stage is x 640-1860 / y 200-1020.
All on-screen text in English. Hook displayed on screen in Scene 1. Zero exclamation marks.

## Locked
- 2026-10-25, Alvin: GO on storyboard and 11-scene build.

---

## Frame 1 - Hook
- scene: Why do magnets stick to your fridge? Fridge door + souvenir magnet snapping + invisible force field lines.
- duration: 7.00s
- src: compositions/s01-hook.html
- blueprint: titlecard-reveal
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Why Do Magnets Stick to Your Fridge?

Narration: "Bakit tumidikit ang magnet sa ref mo? The answer is an invisible force you cannot see."

Beats:
- t=0.10s: Brand open (`Tech Explanasyon explains`) at top band + Hook headline: "Why Do Magnets Stick to Your Fridge?".
- t=1.20s: 3D stainless steel refrigerator panel card slides in with decorative souvenir magnet.
- t=3.20s: Magnet snaps tight with subtle impact vibration; glowing radiant invisible force rings expand outward.
- t=6.45s: Elements sink smoothly into canon floor by t=6.90s.

---

## Frame 2 - Magnetic Domains
- scene: Microscopic view inside iron showing tiny domain regions acting like miniature bar magnets.
- duration: 5.30s
- src: compositions/s02-domains.html
- blueprint: zoom-out-workspace-reveal
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Magnetic Domains Inside Metal

Narration: "Inside a magnet, tiny regions called domains act like miniature magnets."

Beats:
- t=0.10s: Headline lands: "Magnetic Domains Inside Metal".
- t=0.80s: Microscopic crystalline grid card zooms in showing clustered atomic cells.
- t=2.00s: Mini magnetic dipole arrows illuminate inside each domain (`Tiny Micro-Magnets`).
- t=4.75s: Elements sink smoothly into canon floor by t=5.20s.

---

## Frame 3 - Scrambled Raw Iron
- scene: In ordinary unmagnetized iron, domains point in random directions and cancel out to zero.
- duration: 4.60s
- src: compositions/s03-cancel.html
- blueprint: comparison-split
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Scrambled Domains in Raw Iron

Narration: "Sa ordinaryong bakal, nakakalat sila at nagkakansilahan ang lakas nila,"

Beats:
- t=0.10s: Headline: "Scrambled Domains in Raw Iron".
- t=0.70s: Raw iron bar chassis appears with chaotic arrows pointing up, down, left, and right.
- t=2.20s: Cancellation indicator card stamps: `Net Magnetic Force: 0 (Canceled)`.
- t=4.05s: Elements sink smoothly into canon floor by t=4.50s.

---

## Frame 4 - Aligned Domains
- scene: In a permanent magnet, all magnetic domains are locked in parallel alignment.
- duration: 3.30s
- src: compositions/s04-align.html
- blueprint: process-steps
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Locked & Aligned in a Magnet

Narration: "pero sa magnet, halos lahat ay nakahanay."

Beats:
- t=0.10s: Headline: "Locked & Aligned in a Magnet".
- t=0.60s: All domain arrows snap into identical parallel direction in unison.
- t=1.80s: Glowing alignment badge confirms: `100% Aligned Dipoles`.
- t=2.75s: Elements sink smoothly into canon floor by t=3.20s.

---

## Frame 5 - 3D Magnetic Field Lines
- scene: Bar magnet generating continuous magnetic field loops traced by curved iron filings.
- duration: 7.60s
- src: compositions/s05-field.html
- blueprint: dynamic-data-matrix
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Magnetic Field Lines & Iron Filings

Narration: "Ang lakas na iyan ay umaabot bilang magnetic field, na sinusunda ng iron filings sa mga kurba sa pagitan ng dalawang pole."

Beats:
- t=0.10s: Headline: "Magnetic Field Lines & Iron Filings".
- t=0.80s: Two-tone red (North) and blue (South) bar magnet appears at stage center.
- t=2.50s: Curved magnetic flux loops arch through 3D space from North to South.
- t=4.20s: Iron filings texture aligns along the curved loops demonstrating flux path.
- t=7.05s: Elements sink smoothly into canon floor by t=7.50s.

---

## Frame 6 - Attraction vs Repulsion
- scene: Opposite poles attract by merging field lines; like poles repel by pushing outward.
- duration: 3.60s
- src: compositions/s06-poles.html
- blueprint: split-screen-contrast
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Opposite Attract & Like Repel

Narration: "Opposite poles attract, like poles repel,"

Beats:
- t=0.10s: Headline: "Opposite Attract & Like Repel".
- t=0.60s: Left card (`N + S`) snaps together with teal check (`Attract`); Right card (`N + N`) resists with red arrows (`Repel`).
- t=3.05s: Elements sink smoothly into canon floor by t=3.50s.

---

## Frame 7 - Splitting a Magnet
- scene: Cutting a magnet in half immediately creates new North and South poles on each piece.
- duration: 5.00s
- src: compositions/s07-split.html
- blueprint: system-architecture
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Cut Magnet Creates New Poles

Narration: "at kahit hatiin mo ang magnet, bawat piraso ay may north at south pa rin."

Beats:
- t=0.10s: Headline: "Cut Magnet Creates New Poles".
- t=0.70s: Full bar magnet (`N - S`) sliced by a cutting beam in the center.
- t=1.80s: Both halves separate, each instantly forming its own new `N` and `S` poles.
- t=4.45s: Elements sink smoothly into canon floor by t=4.90s.

---

## Frame 8 - Earth as a Giant Magnet
- scene: Earth's molten iron core acting as a planetary dynamo with compass needle aligning to field.
- duration: 5.10s
- src: compositions/s08-earth.html
- blueprint: interactive-orbit
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Earth: A Giant Planetary Magnet

Narration: "Ang earth ay isang giganting magnet at ang field nito ang sinusunda ng compass,"

Beats:
- t=0.10s: Headline: "Earth: A Giant Planetary Magnet".
- t=0.70s: 3D Earth globe appears with magnetic core and surrounding magnetosphere lines.
- t=2.20s: Navigational compass springs up with red needle orienting toward magnetic North.
- t=4.55s: Elements sink smoothly into canon floor by t=5.00s.

---

## Frame 9 - Electromagnetism & Coils
- scene: Electric current passing through copper coil creating a controllable electromagnet.
- duration: 4.10s
- src: compositions/s09-electro.html
- blueprint: kinetic-type-beats
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Electromagnets Powered by Current

Narration: "at ang current sa isang coil ay lumilikhan ng electromagnet."

Beats:
- t=0.10s: Headline: "Electromagnets Powered by Current".
- t=0.60s: Copper coil wound around steel core illuminates with electric current pulses.
- t=2.00s: Switchable status card reveals: `Current ON = Powerful Magnet`.
- t=3.55s: Elements sink smoothly into canon floor by t=4.00s.

---

## Frame 10 - Community Engagement Question
- scene: Heavy-lifting crane magnet with interactive question prompt for viewers.
- duration: 8.20s
- src: compositions/s10-question.html
- blueprint: metric-dashboard
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: What Would You Lift with Super Magnet?

Narration: "Kaya ito ang tanong ko sa inyo. Kung makakagawa ka ng pinakamalakas na magnet sa mundo, ano ang una mong bubuhatin gamit ito?"

Beats:
- t=0.10s: Headline: "What Would You Lift with Super Magnet?".
- t=1.00s: Industrial crane electromagnet card appears with heavy steel chain visual.
- t=3.20s: Tagalog community challenge card springs in: "Kung makakagawa ka ng pinakamalakas na magnet, ano ang una mong bubuhatin?"
- t=7.65s: Elements sink smoothly into canon floor by t=8.10s.

---

## Frame 11 - Sign-off End Card
- scene: Community call to comment, Tech Explanasyon logo and exact sign-off lockup held to 60.00s.
- duration: 6.20s
- src: compositions/s11-close.html
- blueprint: summary-lockup
- rules: spring-pop-entrance, 3d-text-depth-layers
- headline: Tech Explanasyon

Narration: "Ikoment mo sa baba. Follow me for more Tech Explained. See ya."

Beats:
- t=0.10s: Tech Explanasyon big branding lockup with call to action: `.kit-cta` -> `Follow me for more tech explained. See yah.`
- t=1.50s: Speech finishes on "See ya!" at t=3.54s (`57.34s` global); brand card and mascot hold solidly until t=6.20s (`60.00s`).
